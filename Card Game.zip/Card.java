package javaapplication9;

// CS145 Hybrid
// Programmers: 
// 23/04/2022
// Lab 4 - Deck of cards

public class Card implements Comparable<Card>
{
        // are suit and rank
	public int suit;
	public int rank;
	
	@Override
	public int compareTo(Card o) 
	{
	     if (this.rank == (o.rank))
	            return 0;
	     else if ((this.rank) > (o.rank))
	            return 1;
	     else
	           return -1;
	}//end of method
	

}//end of class
