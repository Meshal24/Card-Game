package javaapplication9;

// CS145 Hybrid
// Programmers: 
// 23/04/2022
// Lab 4 - Deck of cards

public class GameTest 
{

  public static void main(String[] args) 
	{
		
		// make game
		Game game = new Game();
				
		// play game
		game.play();
                
                //import a Srack class to the main game
                PStack pStack = new PStack();
                
                //import a Queue class to the main game
                PQueue pQueue = new PQueue();
	}//end of method

}//end of class
