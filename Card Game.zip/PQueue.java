package javaapplication9;

// CS145 Hybrid
// Programmers: 
// 23/04/2022
// Lab 4 - Deck of cards

import java.util.ArrayList;
import java.util.NoSuchElementException;

//Queue Retrieves elements in the same order they were added.
public class PQueue<E>{
    private final ArrayList<E> elements;
    public PQueue(){
        this(10);
    }
    public PQueue(int capacity){
        int initCapacity = capacity > 0 ? capacity : 10;
        elements = new ArrayList<E>(initCapacity);
    }
    public void add(E pushObject){ //add will add the number to the game.
        elements.add(pushObject);
    }
    public void remove(){ //remove will take the number and remove it from the game
        if(elements.isEmpty()){
            throw new NoSuchElementException("Queue is empty, cannot peek.");
        }else{
            elements.remove(0);
        }
    }
    public E peek(){ //peek will take the number but do not remove it from the game
        if(elements.isEmpty()){
            throw new NoSuchElementException("Queue is empty, cannot peek.");
        }
        return elements.remove(0);
    }
    @Override
    public String toString(){
        String res = "";
        for(int i = 0; i < elements.size(); i++){
            res += elements.get(i) + " ";
        }
        return res;
    }//end 0f method
}//end of class