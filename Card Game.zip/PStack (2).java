package javaapplication9;

// CS145 Hybrid
// Programmers: 
// 23/04/2022
// Lab 4 - Deck of cards

import java.util.ArrayList;
import java.util.NoSuchElementException;

//Stack Retrieves elements in the reverse of the order they were added
public class PStack<E> {
    private final ArrayList<E> elements;
    public PStack(){
        this(10);
    }
    public PStack(int capacity){
        int initCapacity = capacity > 0 ? capacity : 10;
        elements = new ArrayList<E>(initCapacity);
    }
    public void push(E pushObject){// push will add the number to the game
        elements.add(pushObject);
    }
    public void pop(){// pop will take the number and remove it from the game
        if(elements.isEmpty()){
            throw new NoSuchElementException("Stack is empty, cannot pop.");
        }
        elements.remove(elements.size() - 1);
    }
    public E peek(){// peek will take the number but do not remove it from the game
        if(elements.isEmpty()){
            throw new NoSuchElementException("Stack is empty, cannot pop.");
        }
        return elements.remove(elements.size() - 1);
    }
    @Override
    public String toString(){
        String res = "";
        for(int i = 0; i < elements.size(); i++){
            res += elements.get(i) + " ";
        }
        return res;
    }// endo of method
}// end of class